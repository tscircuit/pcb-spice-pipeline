import { z } from "zod"

/** Numeric clock times are seconds; string values must include a time unit. */
const clockTime = z.union([
  z.number().finite().positive(),
  z.string().regex(/^\s*\d+(?:\.\d+)?(?:e[+-]?\d+)?\s*(?:s|ms|us|ns|ps)\s*$/i),
])
const ibisClock = z.object({
  type: z.literal("clock"),
  period: clockTime,
  duration: clockTime,
  inverted: z.boolean().optional(),
})

/** Parent port names are keys; `pin` is the physical pin in the IBIS component. */
const ibisPinBinding = z.discriminatedUnion("mode", [
  z
    .object({
      pin: z.string().min(1),
      model: z.string().min(1).optional(),
      mode: z.literal("input"),
    })
    .strict(),
  z.object({
    pin: z.string().min(1),
    model: z.string().min(1).optional(),
    mode: z.literal("output"),
    stimulus: ibisClock,
  }),
])

/** Table-based IBIS import. Package policy and buffer supply bank are explicit. */
export const ibisModelProps = z
  .object({
    source: z.string().min(1).optional(),
    sourceUrl: z.string().url().optional(),
    archivePath: z.string().min(1).optional(),
    sha256: z
      .string()
      .regex(/^[a-f0-9]{64}$/i)
      .optional(),
    component: z.string().min(1),
    pins: z
      .record(z.string(), ibisPinBinding)
      .refine(
        (pins) => Object.keys(pins).length > 0,
        "Select at least one IBIS pin",
      ),
    power: z.object({ vdd: z.string().min(1), vss: z.string().min(1) }),
    corner: z.enum(["typical", "minimum", "maximum"]).optional(),
    packageModel: z.enum(["none", "pin_rlc"]),
  })
  .superRefine((model, context) => {
    if (Boolean(model.source) === Boolean(model.sourceUrl))
      context.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Provide exactly one of source or sourceUrl",
      })
    if (model.sourceUrl && !model.sha256)
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["sha256"],
        message: "URL imports require the SHA-256 of the extracted .ibs bytes",
      })
    if (model.power.vdd === model.power.vss)
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["power"],
        message: "VDD and VSS must map to different ports",
      })
  })

export type IbisModelProps = z.input<typeof ibisModelProps>
