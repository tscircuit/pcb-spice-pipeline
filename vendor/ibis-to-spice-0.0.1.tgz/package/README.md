# ibis-to-spice

Deterministic, table-based IBIS (`.ibs`) conversion to ngspice behavioral subcircuits. Proposed package name: `@tscircuit/ibis-to-spice`.

This repository includes a reusable TypeScript API, a CLI, original-vendor integration tests, and patches that add `ibisModel` to tscircuit's native `<chip>` TSX element. Conversion and simulation run as ordinary code; no LLM service, generated code at runtime, or proprietary IBIS simulator is involved.

The package and upstream patches are implemented locally. They have not been published to npm or merged into tscircuit. The integration command installs the local package and patched props automatically.

## Reproduce

Requires Git and Bun 1.3.14. Node 20+ can use the built API/CLI. The first verification run needs network access for package installation, the two manufacturer archives, and the pinned ngspice WASM engine.

```sh
bun install --frozen-lockfile
bun run check
bun run integration:check
bun run repeatability:check
```

`check` downloads and verifies the original TI AM335x and Winbond W631GG6MB files, runs converter tests/type checking, builds the package, and simulates 72 manufacturer V/T fixtures. `integration:check` checks out pinned tscircuit core/props commits, applies the supplied patches, and tests native TSX conversion and simulation. `repeatability:check` regenerates all 72 netlists and waveforms twice and compares their bytes.

Vendor files are fetched into `.cache/vendors/`. They retain manufacturer copyright and are not redistributed as part of this MIT package. Source URLs, selected archive members and exact file hashes are recorded in [`vendor-fixtures/models.lock.json`](vendor-fixtures/models.lock.json). A changed file fails verification instead of silently changing the simulation.

## Reusable API

```ts
import { resolveIbisModel } from "@tscircuit/ibis-to-spice"

const result = await resolveIbisModel({
  sourceUrl: "https://www.winbond.com/resource-files/w631gg6mb_ibis.zip",
  archivePath: "W631GG6MB-12.ibs",
  sha256: "f2c0f36e24be68fd95a05f34ca4ab875ac5145f1956c5696e9a60b0d8a03e859",
  component: "W631GG6MB-12",
  pins: { DQS: { pin: "F3", model: "ODT_60", mode: "input" } },
  power: { vdd: "VDD", vss: "GND" },
  corner: "typical",
  packageModel: "pin_rlc",
})
// result.source: generated .subckt definitions
// result.spicePinMapping: subcircuit terminal -> parent component port
// result.sourceSha256, result.warnings: provenance / explicit exclusions
```

`source` accepts original IBIS text for offline use; provide exactly one of `source` or `sourceUrl`. URL imports require `sha256` of the extracted `.ibs` bytes. ZIP imports also require `archivePath`. `createIbisModelResolver(fetcher?)` shares pinned downloads across multiple chips in a caller-owned cache. Failed downloads can be retried. `parseIbis` and `convertIbisBuffer` are also exported for lower-level use.

## CLI

```sh
bun run build
node dist/cli.js examples/winbond-receiver.json receiver.cir
```

This writes a SPICE subcircuit file and `receiver.cir.json` with its port mapping, source hash and exclusions. A config may use `inputFile` instead of `sourceUrl`; local paths are relative to the config file. All remaining fields are identical to the API. The CLI emits a nonzero exit code for invalid input.

## Native tscircuit TSX

The supplied integration patches add this prop directly to `<chip>`:

```tsx
<chip
  name="U1"
  pinLabels={{ pin1: "DQS", pin2: "VDD", pin3: "GND" }}
  ibisModel={{
    sourceUrl: "https://www.ti.com/lit/zip/sprm552",
    archivePath: "sprm552c.ibs",
    sha256: "23011a68eb8ff35562615b5b108edcb9f017c5e61f4f68e32f35c5fb88f163be",
    component: "am335x_zcz",
    pins: {
      DQS: {
        pin: "P1", model: "Model_655", mode: "output",
        stimulus: { type: "clock", period: "5ns", duration: "40ns" },
      },
    },
    power: { vdd: "VDD", vss: "GND" },
    corner: "typical",
    packageModel: "none",
  }}
/>
```

`pins` keys and `power` values name ports on the parent TSX chip. Each `pin` value selects a physical pin from the IBIS component; `model` selects an allowed buffer from that pin's vendor selector. Ambiguous selectors require an explicit model. The example's TSX pin numbering is a small test fixture, not an AM335x board footprint. [`examples/ti-winbond-dqs.circuit.tsx`](examples/ti-winbond-dqs.circuit.tsx) supplies a complete differential source/receiver test circuit.

Inputs have no stimulus. Outputs require an explicit clock. Numeric times mean seconds; strings include `s`, `ms`, `us`, `ns` or `ps`. Inverted clocks drive the complementary output. Changing buffer selection, corner, source bytes or stimulus produces a different generated model identity. Parsed props are never mutated. The renderer waits for the import before simulating, reports failures as `ibisModel` property errors, and prevents an incomplete circuit from reaching the simulator. `spiceModel` and `ibisModel` on the same chip conflict. `analogSimulationDisabled` skips imports and simulation.

## Electrical scope

Supported: table-based `Input`, `Output`, `I/O` and `3-state` CMOS buffers used in explicitly selected input or actively driven output mode; typical/minimum/maximum columns; clamp I/V tables; `C_comp`; two independent resistive V/T fixtures per edge; rail-relative behavioral currents; and uncoupled signal-pin R/L/C package parasitics.

Output switching weights are solved from the two fixture equations, including fixture current, die capacitance and clamps. The converter preserves the output I/V tables and adds the clamp currents separately, retaining the vendor table reference voltages, as defined in the [IBIS 4.2 specification](https://ibis.org/ver4.2/ver4_2.pdf). Package capacitance connects to the external pin; die capacitance connects to the buffer pad. Conversion uses piecewise-linear interpolation and a nonuniform finite-difference derivative. There is no guessed ramp or timing fallback.

Choose package policy explicitly. `pin_rlc` uses declared per-pin values, falling back to declared package averages. `none` excludes package parasitics and records that choice. TI's coupled package matrix is currently unsupported, so the TI tests explicitly use `none`; Winbond tests use its declared signal-pin R/L/C. Supply-pin package impedance, differential receiver logic and `[Diff Pin]` delay are not synthesized. The paired test uses two explicitly clocked buffers and observes their voltage difference.

Unsupported selected buffer keywords, external/AMI models, split die capacitances, open-drain outputs, high-Z switching, reactive V/T fixtures, missing corner data, missing pin/model selections and overlapping clock edges fail with a diagnostic. This is a deliberately bounded implementation, not a complete IBIS standard validator or universal vendor-model converter. New supported table-based models reuse the same pipeline; unsupported features need code and regression fixtures.

## Evidence

The tests use complete original files, not hand-written vendor-like snippets. They cover TI `Model_655`/`Model_847`, Winbond `DATA_34`/`DATA_40`/`DATA_60`/`DATA_80`, and Winbond ODT receivers. Each output is simulated for both edges, both resistive fixtures and all three corners: 72 fixture runs. Acceptance limits are RMS <1% of the selected supply and maximum error <5% of supply.

Generated `.cir`, CSV waveforms and `vendor-proof.json` are saved under `proof-results/`. Committed verification reports and the native TSX waveform are under `verification/`. Separate steady-state ngspice tests check the sum of the original output/clamp I/V tables for both vendors, and a Winbond regression checks operation with ground shifted by 2.5 V. The fixture comparisons check consistency with the V/T data used to derive switching weights; they do not independently establish silicon or board accuracy. The native TSX test connects buffers electrically without extracting PCB transmission-line geometry. For an optional plot with nanosecond axes, install `matplotlib==3.11.2` and run `python scripts/plot-proof.py` after the integration check.

## Upstream integration

`integrations/manifest.json` pins the upstream base commits; `props.patch` adds validation/types/docs, and `core.patch` performs native conversion through tscircuit's existing `SpiceModel` and Circuit JSON simulation pipeline. No Circuit JSON schema extension is needed. For upstream publication, publish the converter first, release the props change, then point core at those released versions and update the upstream lockfile. The local bootstrap handles these dependencies without `bun patch`.
